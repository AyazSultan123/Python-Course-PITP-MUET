from flask import Flask, render_template
from datetime import datetime

app = Flask(__name__)

@app.route("/welcome")
def welcome():
    return "<h2 style='color: green; font-family: Arial;'>Welcome to the Flask App!</h2>"

@app.route("/hello/<username>")
def hello_user(username):
    return render_template("hello.html", username=username)

@app.route("/square/<int:number>")
def square(number):
    result = number ** 2
    return f"<h3 style='color: blue; font-family: Arial;'>The square of {number} is {result}</h3>"

@app.route("/repeat/<string:word>/<int:times>")
def repeat_word(word, times):
    repeated = " ".join([word] * times)
    return f"<p style='font-family: Arial; color: purple;'>Repeated word: {repeated}</p>"

@app.route("/info")
def info():
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return f"<h4 style='font-family: Arial; color: darkred;'>Current Date & Time: {now}</h4>"

if __name__ == "__main__":
    app.run(debug=True)
